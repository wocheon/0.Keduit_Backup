<?PHP
$a=getenv('DB_HOST');
$b=getenv('DB_USER');
$c=getenv('DB_PASSWD');
$d=getenv('DB_DATA');
echo $a;
echo $b;
echo $c;
echo $d;
?>
