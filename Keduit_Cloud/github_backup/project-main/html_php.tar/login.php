<!DOCTYPE HTML>
<HTML>
        <head>
                <link rel="stylesheet" href="css1.css" type="text/css">
        <head>

        <body>
<?php
        session_destroy();
        $input_id =$_POST['input1'];
        $input_password =$_POST['input2'];
        include 'include/mariadbcon.php';
        $sql = "SELECT passwd,division from usertbl where userid ='$input_id'";
        $ret = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($ret);
        $s=$row['passwd'];
	
	
	$div=$row['division'];
	
      if (password_verify($input_password, $s)) {
        session_start();
        $_SESSION['id'] = $input_id;
        $_SESSION['div'] = $row['division'];
       echo $_SESSION['id'];
       echo $_SESSION['div'];
        echo("<script>location.href='sshtest.php';</script>");
        }
      else {
        echo("<script>location.href='index.html';</script>");
        }

        mysqli_close($con);
?>
        </body>

</HTML>
