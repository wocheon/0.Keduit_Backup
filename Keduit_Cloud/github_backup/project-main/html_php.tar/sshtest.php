<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" href="css1.css" type="text/css">

</head>
<body>

<?php include 'include/menu.php';?>
		<div id="center1">		             
	<h1> 서비스 신청 페이지 </h1>
			<form action="loading.php" method="post">
                		VMname : &nbsp;&nbsp;<input type="text" name="vmname" style="font-size : 25px; width: 150px;"/><br><br>
                	
				VCPUS :&nbsp;&nbsp;
                	<select name="vcpus" style="font-size : 25px;">
                        	<option value="1">1 core</option>
                        	<option value="2">2 core</option>
                	</select><br><br>
                		
				VRAM :&nbsp;&nbsp;
                	<select name="ram" style="font-size : 25px;">
                        	<option value="1024">1 GB</option>
                        	<option value="2048">2 GB</option>
                	</select><br><br>
                		VMip : &nbsp;&nbsp;<input type="text" name="ip" style="font-size : 25px; width: 150px;"/><br><br>

                		service :&nbsp;&nbsp;
                	
			<select name="service" style="font-size : 25px;">
                        	<option value="wordpress">WordPress</option>
                        	<option value="RDS">RDS</option>
                	</select><br><br><br>
				
		 	<input type="reset" value="reset" style="font-size : 20px;">&nbsp;&nbsp;
                	<input type="submit" value="Next" style="font-size : 20px;" onclick="alert('start create KVM instance!')">
               	</form>
		</div>
</body>
</html>
