<form method="post" action="idcheck.php">
<input type = "text" name="id">
<input type = "submit" value="idcheck"> 
</form>
<?php
$id = $_POST['id'];

if ( $id == "" ){
echo "check your id";}
else
{ echo $id;}
?>
