<!DOCTYPE html>
<html>
<head>
        <title> gallery </title>
</head>

<body>
<!-- 메뉴바-->
<?php include 'include/menu.php'?>

        <h2> img gallay </h2>
        <div style="text-align: center;">
        <img src="img/topology.JPG" >
        <br><br>


<!-- 하단 연락처-->
<?php include 'include/bottom.html'?>

</body>
</html>
