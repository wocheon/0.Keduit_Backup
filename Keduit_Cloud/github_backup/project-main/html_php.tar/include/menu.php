<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css1.css" type="text/css">
<meta charset="utf-8">
</head>
<body>
 <h2> HELLO <?php session_start(); echo $_SESSION['div']." "; echo $_SESSION['id'];?> !</h2>

    <ul> 
      <li><a href="./index.html">홈으로</a></li>
      <li><a href="./user.php">유저목록</a></li>
      <li><a href="./sshtest.php">인스턴스 생성</a></li>
      <li><a href="#Configuration">인스턴스 환경</a></li>
      <li><a href="./index.html">로그아웃</a></li>
    </ul>
   
	<br><br>
</body>
</html>
