<?php 
$a=getenv('DB_HOST');
$b=getenv('DB_USER');
$c=getenv('DB_PASSWD');
$d=getenv('DB_DATA');

$con = mysqli_connect("$a", "$b", "$c","$d") or die ("Mysql connection fail !!!");
echo "mariadb con success!";
?>
