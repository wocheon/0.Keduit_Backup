<!DOCTYPE HTML>

<html>
	<head>
		<title>메인페이지</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<?php include "include/menu.php"?>
	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<h1>인스턴스 생성 사이트</h1>
				<p>본인이 원하는 인스턴스를 마음껏 만들어보세요<br />
				
			</header>

		<!-- Signup Form -->
			<form id="signup-form" method="post" action="#">
			<button type="button" onClick="location.href='http://10.1.1.5/sshtest.php'">인스턴스 만들기</button>
			</form>

		<!-- Scripts -->
			<script src="assets/js/main.js"></script>

	</body>
</html>
