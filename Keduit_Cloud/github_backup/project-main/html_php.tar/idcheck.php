<?php
$input=$_POST['id'];
include 'include/mariadbcon.php';
$sql = "select * from usertbl where userid = '$input'";
$ret = mysqli_query($con, $sql);
$row = mysqli_fetch_array($ret);
$s1=$row['userid'];

if($input==$s1)
{ echo "<script>alert('Used ID!');</script>";
 echo "<script>location.href='signuppage.php';</script>"; }
else
{
echo "<script>alert('OK!');</script>";}
?>

<form name="hiddenform" method="post" action="signuppage.php">
<input type = "hidden" name="id1" value="<?=$input?>">
</form>

<script>
document.hiddenform.submit();
</script>
