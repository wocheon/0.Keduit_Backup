<?php
include 'include/menu.php';
$vmname=$_POST['vmname'];
$vcpus=$_POST['vcpus'];
$vram=$_POST['ram'];
$ip=$_POST['ip'];
$service=$_POST['service'];

if($service == "RDS")
{ $sship = "10.1.1.12";}
else
{ $sship = "10.1.1.11";}

echo $vmname."<br>";
echo $vcpus."<br>";
echo $vram."<br>";
echo $ip."<br>";
echo $service."<br>";
echo $sship."<br>";

system("sshpass -p test123 ssh -T -o StrictHostKeyChecking=no root@$sship 'sh installvm.sh $vmname $vcpus $vram $ip'");
?>

<a href='sshtest.php'>돌아가기</a><br><br>
<a href='#aa.php'> 서비스 목록 확인</a><br><br>
