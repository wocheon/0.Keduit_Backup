<!DOCTYPE HTML>
<HTML>
        <head>
                <link rel="stylesheet" href="css1.css" type="text/css">
        <head>

        <body>
                <div id="center1">
                <h2> SIGN UP PAGE </h2>
		<h3> please insert<br> ID,PASSWORD </h3>
<form method="post" action="idcheck.php">
  &nbsp;ID CHECK <br> <input type = "text" name="id">
<input type = "submit" value="idcheck"><br><br>
</form>
<?php $id1=$_POST['id1'];?>
                                <form action="signup.php" method="post">
                               ID:                                  <input type="text" name="input1" value="<?=$id1?>" readonly/><br><br>
                                Name : <input type="text" name="input3"/><br><br>
                                &nbsp;PS : <input type="password" name="input2"/><br><br>
                               <input type="radio" name="input4" value="manager"/>관리자
                               <input type="radio" name="input4" value="user"/>유저<br><br>


                &nbsp;&nbsp;<input type="submit" value="SIGN UP">
                </form>
                                <form action="index.html" method="post">
                	&nbsp;&nbsp;<input type="submit" value="CANCEL">
                </div>
        </body>

</HTML>
