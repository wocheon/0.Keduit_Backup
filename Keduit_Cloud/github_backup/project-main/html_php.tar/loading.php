   <?php
	SESSION_START();	
	if($_SESSION['div']=="user")
	{echo "<script>alert('권한이 없습니다!');</script>";
	echo("<script>location.href='sshtest.php';</script>");	 } 

        ob_start();
        echo str_pad('', 4096);
	include 'include/menu.php';
        echo "<h1>installing....</h1>";
        echo "<h3>please wait<br>It take a few minute.</h3>";
        $vmname=$_POST["vmname"];
        $vcpus=$_POST["vcpus"];
        $ram=$_POST["ram"];
        $ip=$_POST["ip"];
        $service=$_POST["service"];
        ?>


        <form name="hiddenform" action="createvm.php" method="post" >
        <input type=hidden name=vmname value=<?=$vmname?>>
        <input type=hidden name=vcpus value=<?=$vcpus?>>
        <input type=hidden name=ram value=<?=$ram?>>
        <input type=hidden name=ip value=<?=$ip?>>
        <input type=hidden name=service value=<?=$service?>>
        </form>

        <script>
        document.hiddenform.submit();
        </script>


        <?php
        ob_flush();
        flush();
        ob_end_flush();
        echo("<script>location.href='result.php';</script>");

 ?>
