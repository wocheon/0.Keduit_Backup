name=$1
vcpus=$2
ram=$3
iprows=$(ip ad sh ens32 |grep 10.1.1 | wc -l)
newipnum=$(expr $iprows + 80 )

cp /root/aa/sample/centos_disk10g.qcow2 /root/aa/${name}.qcow2
cp /root/ipchange.sh /root/ipchange1.sh
sed -i "s/changeip/$4/g" /root/ipchange1.sh

virt-customize -a /root/aa/${name}.qcow2 --upload /root/ipchange1.sh:/root/ --firstboot /root/ipchange1.sh --hostname worker$iprows

virt-install --name ${name} --vcpus ${vcpus} --ram ${ram} --noautoconsole  --network bridge=br01  --disk path=/root/aa/${name}.qcow2 --import 


echo "existed ip : $iprows"
echo "new ip :10.1.1.$newipnum"

echo "IPADDR${iprows}=10.1.1.$newipnum">>/etc/sysconfig/network-scripts/ifcfg-ens32
echo "done!"

grub2-mkconfig -o /boot/grub2/grub.cfg
systemctl restart network
ip ad sh ens32

systemctl restart firewalld
