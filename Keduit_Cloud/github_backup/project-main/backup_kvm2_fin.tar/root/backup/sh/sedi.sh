cat sedtest

echo ""
read -p "ip : " ip


sed -i "s/'${ip}:9100',//" /root/sedtest
cat sedtest
