<?php
	$vmname = $_POST["vmname"];
	$userid = $_POST["userid"];
	$conf = $_POST["conf"];
	
	if($conf!=$vmname) 
	{echo "<script>alert('서비스명이 다릅니다!');</script>";
        echo("<script>location.href='deletevm.php?vmname=$vmname';</script>");}
	else{
 	include 'include/mariadbcon.php';
	$sql = "select service_name FROM vmtbl where vmname = '$vmname'";
	$ret = mysqli_query($con,$sql);
	$row = mysqli_fetch_array($ret);
	$service=$row['service_name'];
	
	switch ( $service ){
                case 'wordpress';
	 	$ip="10.1.1.11";
                break;
                case 'RDS';
	 	$ip="10.1.1.12";
                break;
                case 'nginx';
	 	$ip="10.1.1.12";
		break;}

	system("sshpass -p test123 ssh -T -o StrictHostKeyChecking=no root@$ip 'sh /root/aa/sample/destroy.sh $vmname'");
	
	echo "<h1> 서비스삭제 결과 </h1>";
	if($ret) {
		echo $vmname." 서비스삭제됨..";
	}
	else {
		echo "데이터 삭제 실패";
	}
	
	echo "<br><a href='http://10.1.1.5/inslist_user.php'><-- 돌아가기</a>";
	mysqli_close($con);
	}	

?>
