<?php
include 'include/menu.php';
$vmname=$_POST['vmname'];
$flaver=$_POST['flaver'];
$userid=$_POST['userid'];

$sship = "10.1.1.12";

echo $vmname."<br>";
echo $flaver."<br>";
echo $userid."<br>";

system("sshpass -p test123 ssh -T -o StrictHostKeyChecking=no root@$sship 'sh installvm_nginx.sh $vmname $flaver $userid'");
?>

<a href='index.php'>돌아가기</a><br><br>
<a href='inslist_user.php'> 서비스 목록 확인</a><br><br>
