<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <title>DB CHECK</title>
 <link rel="stylesheet" href="css1.css" type="text/css">

</head>
<body>
<?php include 'include/menu.php'; ?>
        <h2>회원 정보 수정</h2>




<form method="post" action="update_result.php">
<input type="hidden"  name="oldid" value=<?=$_GET['userid']?>>
회원ID : <input type="text"  name="userid" value=<?=$_GET['userid']?>><br><br>

비밀번호 : <input type="input" name="passwd" required><br><br>

회원이름: <input type="text" name="username" required><br><br>
<?php 
SESSION_START();
if($_SESSION['div'] == "manager") { ?>
권한변경: <select name="division" style="font-size : 15px;">
<option value="user">user</option>
<option value="manager">manager</option>
</select>
<?php } ?>


 <input type="submit" value="정보 수정">
                </form>

<br>

<button type="button" class="navyBtn" onClick="location.href='user.php'"> 이전으로 </button>


</body>
</html>
