<?php
include 'include/menu.php';
$vmname=$_POST['vmname'];
$flaver=$_POST['flaver'];
$userid=$_POST['userid'];
$dbuser=$_POST['dbuser'];
$dbpass=$_POST['dbpass'];
$dbdb=$_POST['dbdb'];
$dbroot=$_POST['dbroot'];

$sship = "10.1.1.12";

echo $vmname."<br>";
echo $flaver."<br>";
echo $userid."<br>";

shell_exec("sshpass -p test123 ssh -T -o StrictHostKeyChecking=no root@$sship 'sh installvm.sh $vmname $flaver $userid $dbuser $dbpass $dbdb $dbroot'");

echo "install finished!";
?>
<br>
<a href='index.php'>돌아가기</a><br><br>
<a href='inslist_user.php'> 서비스 목록 확인</a><br><br>
