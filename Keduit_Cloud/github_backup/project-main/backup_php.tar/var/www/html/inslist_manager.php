<?php include 'include/menu.php'?>
<?php include 'include/mariadbcon.php'?>

<!-- 1.Mariadb와 연결 여부 확인, view테이블에서 몇줄이 나오는지 확인-->
        <p>
        <?php
        $sql1 = "SELECT * FROM hosttbl";
        $ret1 = mysqli_query($con, $sql1);

                ?>
        </p>

<!-- 2.불러온 데이터를 이용하여 테이블 생성-->
        <div align="center">
                <h1> All HOST list </h1>
		<?php
		if ($ret1) {
        echo "(".mysqli_num_rows($ret1), "개 서비스 동작중)"."<br>"."<br>";
        }

        else {
        echo "데이터 조회실패!!"."<br>";
        exit();
        }
	?>


                <?php
                echo"<TABLE>";
                echo"<TR>";
                echo "<TH>Hostname</TH><TH>ipaddr</TH><TH>cpurate</TH><TH>instance_num</TH><TH>SSH 연결</TH>";
                echo"</TR>";

                while($row1 = mysqli_fetch_array($ret1)) {
                        echo "<TR>";
                        $ipaddr1=$row1['ipaddr'];
                        echo "<TD>".$row1['hostname']."</TD>";
                        echo "<TD>".$row1['ipaddr']."</TD>";
                        echo "<TD>".$row1['cpurate']."</TD>";
                        echo "<TD>".$row1['instance_num']."</TD>";
                        echo "<TD><a href='https://$ipaddr1:4200'>연결하기</a></TD>";
                        echo "</TR>";
                }
                echo"</TABLE>";
                ?>
        </div>
<!-- hostlist END -->

        
<!-- 1.Mariadb와 연결 여부 확인, view테이블에서 몇줄이 나오는지 확인-->        
        <p>
        <?php
        $sql = "SELECT * FROM vmtbl";
        $ret = mysqli_query($con, $sql);

       ?>
        </p>

<!-- 2.불러온 데이터를 이용하여 테이블 생성-->
        <div align="center">
                <h1> all service list </h1>
		<?php
		 if ($ret) {
        echo "(".mysqli_num_rows($ret), "개 서비스 동작중)"."<br>"."<br>";
        }

        else {
        echo "데이터 조회실패!!"."<br>";
        exit();
        }?>
        

                <?php
                echo"<TABLE>";
                echo"<TR>";
                echo "<TH>Hostname</TH><TH>vmname</TH><TH>userid</TH><TH>vmport</TH><TH>vm's hostname</TH><TH>ip1</TH><TH>ip2</TH><TH>vcpus</TH><TH>vram</TH><TH>service</TH><TH>connect</TH><TH>Console</TH><TH>서비스 삭제</TH>";
                echo"</TR>";

                while($row = mysqli_fetch_array($ret)) {
                        echo "<TR>";
                        echo "<TD>".$row['hostname']."</TD>";
                        echo "<TD>".$row['vmname']."</TD>";
                        echo "<TD>".$row['userid']."</TD>";
                        echo "<TD>".$row['vmport']."</TD>";
                        echo "<TD>".$row['vmhostname']."</TD>";
                        echo "<TD>".$row['vmip1']."</TD>";
                        echo "<TD>".$row['vmip2']."</TD>";
                        echo "<TD>".$row['vcpus']."</TD>";
                        echo "<TD>".$row['vram']."</TD>";
                        echo "<TD>".$row['service_name']."</TD>";
			 $servicenum = $row['service_name'];
                        $addr = $row['vmip2'];
                        switch ( $servicenum ){
                                case 'wordpress';
                                echo "<TD><a href='http://$addr'>연결하기</a></TD>";
                                break;
                                case 'RDS';
                                echo "<TD>X</TD>";
                                break;
                                case 'nginx';
                                echo "<TD><a href='http://$addr'target='_blank'>연결하기</a></TD>";
                                break;}

                        echo "<TD><a href='https://$addr:4200' target='_blank'>콘솔연결</a></TD>";
                        $vmname=$row['vmname'];
                        echo "<TD><a href='./deletevm.php?vmname=$vmname'>삭제
하기</a></TD>";

                        echo "</TR>";
                }
                echo"</TABLE>";
                mysqli_close($con);
                ?>
        </div>
