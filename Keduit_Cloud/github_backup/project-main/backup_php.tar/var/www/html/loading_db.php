   <?php
/*	SESSION_START();	
	if($_SESSION['div']=="user")
	{echo "<script>alert('권한이 없습니다!');</script>";
	echo("<script>location.href='index.php';</script>");	 } 
*/

        ob_start();
        echo str_pad('', 4096);
	include 'include/menu.php';
	$vmname=$_POST["vmname"];
        if ( $vmname ==  "" )
        { echo "<script>alert('먼저 중복체크를 해주세요!');</script>";
         echo "<script>location.href='sshtest_db.php';</script>";}

        echo "<h1>installing....</h1>";
        echo "<h3>please wait<br>It take a few minute.</h3>";
        $vmname=$_POST["vmname"];
        $flaver=$_POST["flaver"];
	$userid=$_SESSION['id'];
	$dbuser=$_POST["dbuser"];
        $dbpass=$_POST["dbpass"];
        $dbdb=$_POST["dbdb"];
        $dbroot=$_POST["dbroot"];

        ?>


        <form name="hiddenform" action="createvm_db.php" method="post" >
        <input type=hidden name=vmname value=<?=$vmname?>>
        <input type=hidden name=flaver value=<?=$flaver?>>
        <input type=hidden name=userid value=<?=$userid?>>
	<input type=hidden name=dbuser value=<?=$dbuser?>>
        <input type=hidden name=dbpass value=<?=$dbpass?>>
        <input type=hidden name=dbdb value=<?=$dbdb?>>
        <input type=hidden name=dbroot value=<?=$dbroot?>>

        </form>

        <script>
        document.hiddenform.submit();
        </script>


        <?php
        ob_flush();
        flush();
        ob_end_flush();
        echo("<script>location.href='result.php';</script>");

 ?>
