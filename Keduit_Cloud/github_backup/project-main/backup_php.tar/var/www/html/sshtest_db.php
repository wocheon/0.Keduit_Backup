<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" href="css1.css" type="text/css">

</head>
<body>

<?php include 'include/menu.php';?>
		<div id="center1">		             
	<h1> MariaDB 서비스 신청 </h1>
	<?php $id1=$_POST['id1'];?>
        <form method="post" action="vmcheck.php">
          서비스명 :  <input type = "text" name="id" value="<?=$id1?>" style="font-size : 25px; width: 150px;">
	 <input type="hidden" name="service" value="db"/>
        <input type = "submit" value="namecheck"><br><br>
	</form>
			<form action="loading_db.php" method="post">
                <input type="hidden" name="vmname" value="<?=$id1?>"/> 	
				FLAVER :&nbsp;&nbsp;
                	<select name="flaver" style="font-size : 25px;">
                        	<option value="1">flaver 1 : cpu 1 ram 1024</option>
                        	<option value="2">flaver 2 : cpu 2 ram 1024</option>
                        	<option value="3">flaver 3 : cpu 2 ram 2048</option>
                	</select><br><br>

<h3> -선택사항 - </h3>  <br>
                		Example DBname : &nbsp;&nbsp;<input type="text" name="dbdb" value="exampledb" style="font-size : 25px; width: 150px;"/><br><br>
                		DBuser : &nbsp;&nbsp;<input type="text" name="dbuser" style="font-size : 25px; width: 150px;"/><br><br>
                		DBpassword : &nbsp;&nbsp;<input type="text" name="dbpass" style="font-size : 25px; width: 150px;"/><br><br>
                		DB_root password : &nbsp;&nbsp;<input type="text" name="dbroot" style="font-size : 25px; width: 150px;"/><br><br>
		 	<input type="reset" value="reset" style="font-size : 20px;">&nbsp;&nbsp;
                	<input type="submit" value="Next" style="font-size : 20px;" onclick="alert('start create KVM instance!')">
	&nbsp;&nbsp;<input type="button" value="Back" onClick="location.href='selectservice.php'" style="font-size : 20px;">
               	</form>
		</div>
</body>
</html>
