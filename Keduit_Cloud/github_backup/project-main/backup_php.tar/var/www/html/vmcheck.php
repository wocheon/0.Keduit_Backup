<?php
$input=$_POST['id'];
$service=$_POST['service'];
 switch ( $service ){
	case 'wp';
	$srv="wp";
        break;
        case 'db';
	$srv="db";
        break;
        case 'web';
	$srv="web";
        break;}

include 'include/mariadbcon.php';
$sql = "select * from vmtbl where vmname = '$input'";
$ret = mysqli_query($con, $sql);
$row = mysqli_fetch_array($ret);
$s1=$row['vmname'];

if($input==$s1)
{ echo "<script>alert('Used ID!');</script>";
 echo "<script>location.href='sshtest_$srv.php';</script>"; }
else
{
echo "<script>alert('OK!');</script>";}
?>

<form name="hiddenform" method="post" action="sshtest_<?=$srv?>.php">
<input type = "hidden" name="id1" value="<?=$input?>">
</form>

<script>
document.hiddenform.submit();
</script>
