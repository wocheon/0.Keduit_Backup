
<?php include 'include/menu.php'?>
<?php include 'include/mariadbcon.php'?> 
<!-- 1.Mariadb와 연결 여부 확인, view테이블에서 몇줄이 나오는지 확인-->        
        <p>
        <?php
	$id=$_SESSION['id'];
        $sql = "SELECT vmname,vmip2,vcpus,vram,service_name FROM vmtbl where userid= '$id'";
        $ret = mysqli_query($con, $sql);

        
        ?>
        </p>

<!-- 2.불러온 데이터를 이용하여 테이블 생성-->
        <div align="center">
                <h1> my service list </h1>
		<?php
		if ($ret) {
        echo "(".mysqli_num_rows($ret), "개 서비스를 보유중)"."<br>"."<br>";
        }

        else {
        echo "데이터 조회실패!!"."<br>";
        exit();
        } ?>

                <?php
                echo"<TABLE>";
                echo"<TR>";
                echo "<TH>servicename</TH><TH>ip</TH><TH>vcpus</TH><TH>vram</TH><TH>service</TH><TH>connect</TH><TH>Console</TH><TH>서비스 삭제</TH>";
                echo"</TR>";

                while($row = mysqli_fetch_array($ret)) {
                        echo "<TR>";
                        echo "<TD>".$row['vmname']."</TD>";
                        echo "<TD>".$row['vmip2']."</TD>";
                        echo "<TD>".$row['vcpus']."</TD>";
                        echo "<TD>".$row['vram']."</TD>";
                        echo "<TD>".$row['service_name']."</TD>";
			$servicenum = $row['service_name'];
			$addr = $row['vmip2'];	
			switch ( $servicenum ){
				case 'wordpress';
				echo "<TD><a href='http://$addr'>연결하기</a></TD>";
				break;
				case 'RDS';
				echo "<TD>X</TD>";
				break;	
				case 'nginx';
				echo "<TD><a href='http://$addr'target='_blank'>연결하기</a></TD>";
				break;}
			
			echo "<TD><a href='https://$addr:4200' target='_blank'>콘솔연결</a></TD>";
			$vmname=$row['vmname'];
			echo "<TD><a href='./deletevm.php?vmname=$vmname'>삭제하기</a></TD>";

                        echo "</TR>";
                }
                echo"</TABLE>";
                mysqli_close($con);
                ?>
        </div>
