<!DOCTYPE html>
<html>
<head>
        <title> mysqlcontest </title>
        <link rel="stylesheet" href="css1.css" type="text/css">
</head>

<body>
<!-- 메뉴바-->        
<?php include 'include/menu.php';
 include 'include/mariadbcon.php';


 SESSION_START();
        if($_SESSION['div']=="user")
        {echo "<script>alert('권한이 없습니다!');</script>";
        echo("<script>location.href='index.php';</script>");   }
        ?>
<!-- 1.Mariadb와 연결 여부 확인, view테이블에서 몇줄이 나오는지 확인-->        
        <p>
        <?php
        $sql = "SELECT * FROM usertbl";
        $ret = mysqli_query($con, $sql);

        if ($ret) {
        echo "(현재".mysqli_num_rows($ret), "명 등록)"."<br>"."<br>";
        }

        else {
        echo "데이터 조회실패!!"."<br>";
        exit();
        }
        ?>
        </p>

<!-- 2.불러온 데이터를 이용하여 테이블 생성-->
        <div align="center">
                <h1> user list </h1>

                <?php
                echo"<TABLE>";
                echo"<TR>";
                echo "<TH>ID</TH><TH>이름</TH><TH>권한</TH><TH>삭제</TH><TH>수정</TH>";
                echo"</TR>";

                while($row = mysqli_fetch_array($ret)) {
                        echo "<TR>";
                        echo "<TD>".$row['userid']."</TD>";
                        echo "<TD>".$row['username']."</TD>";
                        echo "<TD>".$row['division']."</TD>";
			echo "<td>"."<a href='delete.php?userid=",$row['userid'],"'>삭제</a></td>";
			echo "<td>"."<a href='update.php?userid=",$row['userid'],"'>수정</a></td>";
                        echo "</TR>";
                }
                echo"</TABLE>";
                ?>
        </div>

<!-- 하단 연락처-->        
</body>
</html>
