<DOCTYPE html>
<html>
<head>
        <title>삭제회원 확인 페이지</title>
</head>
<body>
<?php include 'include/menu.php'?>
<?php include 'include/mariadbcon.php'?>
<?php
        //A가 삭제했는데.. B에서 삭제하려고 하면 정보가 없을 수 있다
        $id=$_GET['userid']; 
	$sql = "SELECT * FROM usertbl where userid= '$id'";
        $ret = mysqli_query($con, $sql); 
	if($ret) {
                $count = mysqli_num_rows($ret);
                if($count == 0) {
                        echo "해당 사용자는 없습니다<br>";
                        echo "<br><a href='http://10.1.1.5/user.php'><-- 돌아가기</a>";
                        exit();
                }
        }
        else {
                echo "데이터 조회 실패<br>";
                echo "<br><a href='http://10.1.1.5/user.php'><-- 돌아가기</a>";
                exit();
        }


        $row = mysqli_fetch_array($ret);
        $userid = $row['userid'];
        $username = $row['username'];

?>
        <h2>회원 삭제 확인</h2>
        <?php
                echo "$count 건의 삭제 정보가 검색 되었습니다<br><br>"
        ?>

        <form method="post" action="delete_result.php">
        아이디 : <input type = "text" name="userid" value=<?php echo $userid ?> READONLY><br>
        이름 : <input type = "text" name="username" value=<?php echo $username ?> READONLY><br>

        <br><br>
        위 회원을 삭제하겠습니까? &nbsp;&nbsp;&nbsp;<input type="submit" value="회원삭제">

        </form>

</body>
</html>

