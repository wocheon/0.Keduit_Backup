<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8"/>
    <style>
    div {
        width: 100%;
        height: 300px;
        
        border: 1px solid #fff;
    }
    div.left {
        width: 50%;
        float: left;
        box-sizing: border-box;
        
    }
    div.right {
        width: 50%;
        float: right;
        box-sizing: border-box;
        
    }

div.bb {

width:100%;
height:100%;
background-color:yellow;
float:left;}

    </style>

</head>
<body>

<?php include 'include/menu.php';?>

<!-- 본문-->

        <div style="font-size:4.5em; font-family:impact; color: green " align="center">
        welcome to ALOE PROJECT!<br>
	 
        <br>
        </div>




<!-- 본문-이미지 -->
        <div class="frame">
<div class="container">
<div class="nav" style="font-size:2em; font-family:impact; color:#003458"; >

        <img src="img/Snap4.jpg" width="600" height="500">
</div>
<div class="content" style="font-size:2em; font-family:impact; color:#003458"; >
        
<br>
	<p> 서비스로서의 플랫폼(Platform-as-a-service, PaaS)은 하드웨어 및 애플리케이션 소프트웨어 플랫폼이 제3사를 통해 제공되는 클라우드 컴퓨팅의 한 형식입니다. >주로 개발자와 프로그래머가 사용하는 PaaS는 보통 해당 프로세스와 관련된 인프라 또는 플랫폼을 구축하고 유지관리할 필요 없이 자체 애플리케이션을 개발, 실행 및 관리 할 수 있도록 해줍니다.

PaaS 제공업체는 자체 인프라에서 하드웨어와 소프트웨어를 호스팅하고 이러한 플랫폼을 사용자에게 통합 솔루션, 솔루션 스택 또는 인터넷을 통한 서비스로 제공합니>다.

예를 들어 일상 업무 간소화를 지원하는 애플리케이션에 대한 좋은 아이디어가 떠올라 코드를 작성했다고 가정해 보겠습니다. 이러한 애플리케이션의 활용 범위와 잠재
적 가능성을 기대하게 됩니다. 온프레미스 하드웨어 설치, 서버 유지관리, 인프라 소프트웨어를 최신 상태로 유지, 애플리케이션을 개발할 사용자 지정 플랫폼 구축 등
과 관련된 추가 부담을 피하려면 이러한 플랫폼을 호스팅하고 코드 실행에 필요한 환경을 제공하는 PaaS 제공업체를 이용하면 됩니다.<br>
</p>

        <br>
        <br>
        </div>
</div>
<div class="footer">
	<p class="copyright">&copy;copy</p>
<?php include 'include/bottom.html';?>


</div>


</div>


</body>

</html>


