<?php
include 'include/mariadbcon.php';
include 'include/menu.php';
$userid=$_POST['userid'];
$username=$_POST['username'];
$passwd=$_POST['passwd'];
$division=$_POST['division'];
$oldid=$_POST['oldid'];

SESSION_START();

$idcheck=$_SESSION['id'];

if ($idcheck==$oldid)
{$_SESSION['id']==$userid;}


$hashpass = password_hash($passwd,PASSWORD_DEFAULT);


$sql = "update usertbl set userid = '$userid', passwd = '$hashpass', username = '$username', division = '$division' where userid = '$oldid' ";

        $ret = mysqli_query($con,$sql);

        if ($ret)
        {
        echo "<script>alert('정보수정 완료!');</script>";
        echo "<script>location.href='index.php';</script>";}

         else
        {
        echo "<script>alert('정보수정  실패!');</script>";
        echo "<script>location.href='index.php';</script>";}


        mysqli_close($con);

?>
~

