<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" href="css1.css" type="text/css">

</head>
<body>

<?php include 'include/menu.php';?>
		<div id="center1">		             
	<h1> 서비스 신청 페이지 </h1>
			<form action="loading.php" method="post">
                		VMname : &nbsp;&nbsp;<input type="text" name="vmname" style="font-size : 25px; width: 150px;"/><br><br>
                	
				FLAVER :&nbsp;&nbsp;
                	<select name="flaver" style="font-size : 25px;">
                        	<option value="1">flaver 1 : cpu 1 ram 1024</option>
                        	<option value="2">flaver 2 : cpu 2 ram 1024</option>
                        	<option value="3">flaver 3 : cpu 2 ram 2048</option>
                	</select><br><br>

                		service :&nbsp;&nbsp;
			<select name="service" style="font-size : 25px;">
                        	<option value="wordpress">WordPress</option>
                        	<option value="RDS">RDS</option>
                	</select><br><br><br>
				
		 	<input type="reset" value="reset" style="font-size : 20px;">&nbsp;&nbsp;
                	<input type="submit" value="Next" style="font-size : 20px;" onclick="alert('start create KVM instance!')">
               	</form>
		</div>
</body>
</html>
