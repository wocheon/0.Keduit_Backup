<?php
include 'include/menu.php';
?>
<div id="center">


<div class="header">
<h1> 신청 서비스 선택 </h1><br><br>
<h2> 이미지 선택시 신청페이지로 이동합니다 </h2>
<br><br><br>

         <div style="float: left; width: 33%;">
                <a href="sshtest_wp.php" style="text-decoration:none">
                <img src="img/wordpress.png" width="200" height="200" alt="wordpress">
            
            <div class="text">
                <h1>wordpress</h1>
         </div>
	</div>


         <div style="float: left; width: 33%;">

                <a href="sshtest_db.php" style="text-decoration:none">
                <img src="img/mariadb.png" width="200" height="200">
            <div class="text">
                <h1>mariaDB</h1>
         </div>
</div>

         <div style="float: left; width: 33%;">

                <a href="sshtest_web.php" style="text-decoration:none">
                <img src="img/nginx.png" width="200" height="200">
           
            <div class="text">
                <h1>nginx</h1>


</div>
</div>
</div>
</div>

</div>
