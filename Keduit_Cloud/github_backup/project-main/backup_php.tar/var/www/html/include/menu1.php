<!DOCTYPE HTML>




<html>
	<head>
		<title>나색: 나만의 색상을 찾기</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="testcss.css" />


	</head>
	<body class="is-preload">







<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<header id="header">
									<a href="index.html" class="logo"><strong>인스턴스</strong> '나만의 인스턴스 만들기'</a>
									<ul class="icons">
										<li><a href="#" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
										<li><a href="#" class="icon brands fa-snapchat-ghost"><span class="label">Snapchat</span></a></li>
										<li><a href="#" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
										<li><a href="#" class="icon brands fa-medium-m"><span class="label">Medium</span></a></li>
									</ul>
								</header>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<header>
											<h1>'나인' <br />
											나만의 인스턴스 만들기</h1>
											<p>누구에게나 어울리는 색상은 존재합니다.</p>
										</header>
										<p>PaaS 는 하드웨어 및 애플리케이션 소프트웨어 플랫폼이 제3사를 통해 제공되는 클라우드 컴퓨팅의 한 형식입니다. 주로 개발자와 프로그래머가 사용하는 PaaS는 보통 해당 프로세스와 관련된 인프라 또는 플랫폼을 구축하고 유지관리
할 필요 없이 자체 애플리케이션을 개발, 실행 및 관리 할 수 있도록 해줍니다. 지금 바로 시작해보세요!</p>
										<ul class="actions">
											<li><a href="#" class="button big">더 알아보기</a></li>
										</ul>
									</div>
									<span class="image object">
										<img src="images/pic10.png" alt="" />
									</span>
								</section>

							<!-- Section -->
								<section>
									<header class="major">
										<h2>PaaS의 장점</h2>
									</header>
									<div class="features">
										<article>
											<span class="icon fa-gem"></span>
											<div class="content">
												<h3>코딩 시간 단축</h3>
												<p>PaaS 개발 도구는 플랫폼에 기본 제공되는 미리 코딩된 애플리케이션 구성 요소(예: 워크플로, 디렉터리 서비스, 보안 기능, 검색 등)로 새로운 앱을 코딩하는 데 걸리는 시간을 줄여줄 수 있습니다.</p>
											</div>
										</article>
										<article>
											<span class="icon solid fa-paper-plane"></span>
											<div class="content">
												<h3>직원 추가 없이 개발 능력 추가</h3>
												<p>Platform as a Service 구성 요소는 필요한 기술을 보유한 직원을 추가할 필요 없이 개발 팀에 새로운 능력을 제공할 수 있습니다..</p>
											</div>
										</article>
										<article>
											<span class="icon solid fa-rocket"></span>
											<div class="content">
												<h3>모바일을 비롯한 여러 플랫폼용으로 더 쉽게 개발</h3>
												<p>일부 서비스 공급자는 컴퓨터, 모바일 장치 및 브라우저와 같은 여러 플랫폼용 개발 옵션을 제공하여 플랫폼 간 앱을 더 빠르고 쉽게 개발할 수 있게 합니다.</p>
											</div>
										</article>
										<article>
											<span class="icon solid fa-signal"></span>
											<div class="content">
												<h3>지리적으로 분산된 개발 팀 지원</h3>
												<p>인터넷을 통해 개발 환경에 액세스하므로 개발 팀은 팀 멤버가 원격 위치에 있는 경우에도 프로젝트에 대해 함께 작업할 수 있습니다.</p>
											</div>
										</article>
									</div>
								</section>

							<!-- Section -->
								

						</div>
					</div>

				<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Search -->
								<section id="search" class="alt">
									 <div style="color: green; font-family: impact; font-size: 2em; display: inline-block;">
        <img src="images/aloe-vera-fresh-logo-green-leaf_129883-19.jpg" width="70" height="70">
        </div><div style="color: green; font-family: impact; font-size: 2em; display: inline-block;">PROJECT ALOE
        </div>

									
									
								</section>

							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>메뉴</h2>
									</header>
									<ul>
										<li><a href="http://10.1.1.5/index.php">홈페이지</a></li>
										<li><a href="http://10.1.1.5/user.php">유저목록</a></li>
										<li><a href="http://10.1.1.5/inslist_manager.php">전체 서비스 목록</a></li>
										<li>
											<span class="opener">오늘의 추천</span>
											<ul>
												<li><a href="#">Lorem Dolor</a></li>
												<li><a href="#">Ipsum Adipiscing</a></li>
												<li><a href="#">Tempus Magna</a></li>
												<li><a href="#">Feugiat Veroeros</a></li>
											</ul>
										</li>
										<li><a href="http://10.1.1.5/selectservice.php">서비스 신청</a></li>
										<li><a href="http://10.1.1.5/inslist_user.php">내 서비스 현황</a></li>
										<li><a href="#">로그아웃</a></li>
									</ul>
								</nav>

							<!-- Section -->
								

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Get in touch</h2>
									</header>
									<p>Sed varius enim lorem ullamcorper dolore aliquam aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin sed aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>
									<ul class="contact">
										<li class="icon solid fa-envelope"><a href="#">information@untitled.tld</a></li>
										<li class="icon solid fa-phone">(000) 000-0000</li>
										<li class="icon solid fa-home">1234 Somewhere Road #8254<br />
										Nashville, TN 00000-0000</li>
									</ul>
								</section>

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; Untitled. All rights reserved. Demo Images: <a href="https://unsplash.com">Unsplash</a>. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
								</footer>

						</div>
					</div>

			</div>



</body>
</html>
