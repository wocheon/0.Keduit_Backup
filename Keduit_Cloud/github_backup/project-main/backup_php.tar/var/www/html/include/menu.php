<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css1.css" type="text/css">
<meta charset="utf-8">
</head>
<body>
    <div style="color: green; font-family: impact; font-size: 2em; display: inline-block;">
        <img src="img/logo.png" width="50" height="50" style="background-color: rgba(255,255,255,0.75);">
        PROJECT ALOE
        </div>
 <div style="display: inline-block; font-size: 1.2em; margin: 10px;"><?php session_start(); echo "[".$_SESSION['div']."] "; echo $_SESSION['id'];?> </div>

    <ul> 
      <li><a href="./index.php">홈으로</a></li>
<?php 
if ($_SESSION['div'] == "manager"){?>
      <li><a href="./user.php">유저목록</a></li>
      <li><a href="./inslist_manager.php">전체 서비스 목록</a></li>
<?php } ?>
      <li><a href="./selectservice.php">서비스 신청</a></li>
      <li><a href="./inslist_user.php">내 서비스 현황</a></li>
      <li><a href="./update.php?userid=<?=$_SESSION['id']?>">회원정보 수정</a></li>
      <li><a href="./index.html">로그아웃</a></li>
    </ul>
   
	<br><br>
</body>
</html>
