<?php include 'include/mariadbcon.php'?>
<?php
	SESSION_START();
	$userid = $_POST["userid"];
	$checkid = $_SESSION['id'];
	echo $checkid;
	echo $userid;

	$sql = "DELETE FROM usertbl where userid = '$userid'";
	$ret = mysqli_query($con,$sql);

	echo "<h1> 회원삭제 결과 </h1>";
	if($ret) {
		echo $userid." 회원삭제됨..";
	}
	else {
		echo "데이터 삭제 실패";
	}
	

	if($checkid == $userid)
	{
	  echo "<script>location.href='index.html';</script>";}
	


	echo "<br><a href='http://10.1.1.5/user.php'><-- 돌아가기</a>";
	mysqli_close($con);
	

?>
