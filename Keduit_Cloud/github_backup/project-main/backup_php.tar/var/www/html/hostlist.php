<head>
<style>

<?php include 'include/menu.php'?>

<?php include 'include/mariadbcon.php'?>
        
<!-- 1.Mariadb와 연결 여부 확인, view테이블에서 몇줄이 나오는지 확인-->        
        <p>
        <?php
        $sql = "SELECT * FROM hosttbl";
        $ret = mysqli_query($con, $sql);

        if ($ret) {
        echo "(".mysqli_num_rows($ret), "개 서비스 동작중)"."<br>"."<br>";
        }

        else {
        echo "데이터 조회실패!!"."<br>";
        exit();
        }
        ?>
        </p>

<!-- 2.불러온 데이터를 이용하여 테이블 생성-->
        <div align="center">
                <h1> All HOST list </h1>

                <?php
                echo"<TABLE>";
                echo"<TR>";
                echo "<TH>Hostname</TH><TH>ipaddr</TH><TH>cpurate</TH><TH>instance_num</TH><TH>SSH 연결</TH>";
                echo"</TR>";

                while($row = mysqli_fetch_array($ret)) {
                        echo "<TR>";
			$ipaddr=$row['ipaddr'];
                        echo "<TD>".$row['hostname']."</TD>";
                        echo "<TD>".$row['ipaddr']."</TD>";
                        echo "<TD>".$row['cpurate']."</TD>";
                        echo "<TD>".$row['instance_num']."</TD>";
                        echo "<TD><a href='https://$ipaddr:4200'>연결하기</a></TD>";
                        echo "</TR>";
                }
                echo"</TABLE>";
                mysqli_close($con);
                ?>
        </div>
