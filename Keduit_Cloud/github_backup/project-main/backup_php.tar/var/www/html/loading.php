   <?php
/*	SESSION_START();	
	if($_SESSION['div']=="user")
	{echo "<script>alert('권한이 없습니다!');</script>";
	echo("<script>location.href='index.php';</script>");	 } 
*/

        ob_start();
        echo str_pad('', 4096);
	include 'include/menu.php';
        echo "<h1>installing....</h1>";
        echo "<h3>please wait<br>It take a few minute.</h3>";
        $vmname=$_POST["vmname"];
        $flaver=$_POST["flaver"];
        $service=$_POST["service"];
	$userid=$_SESSION['id'];
        ?>


        <form name="hiddenform" action="createvm.php" method="post" >
        <input type=hidden name=vmname value=<?=$vmname?>>
        <input type=hidden name=flaver value=<?=$flaver?>>
        <input type=hidden name=userid value=<?=$userid?>>
        <input type=hidden name=service value=<?=$service?>>
        </form>

        <script>
        document.hiddenform.submit();
        </script>


        <?php
        ob_flush();
        flush();
        ob_end_flush();
        echo("<script>location.href='result.php';</script>");

 ?>
