<DOCTYPE html>
<html>
<head>
        <title>서비스 삭제 확인 페이지</title>
</head>
<body>
<?php include 'include/menu.php'?>
<?php include 'include/mariadbcon.php'?>
<?php
        //A가 삭제했는데.. B에서 삭제하려고 하면 정보가 없을 수 있다
        $vmname=$_GET['vmname']; 
	$sql = "SELECT * FROM vmtbl where vmname= '$vmname'";
        $ret = mysqli_query($con, $sql); 
	if($ret) {
                $count = mysqli_num_rows($ret);
                if($count == 0) {
                        echo "해당 서비스는 없습니다<br>";
                        echo "<br><a href='http://10.1.1.5/inslist_user.php'><-- 돌아가기</a>";
                        exit();
                }
        }
        else {
                echo "데이터 조회 실패<br>";
                echo "<br><a href='http://10.1.1.5/inslist_user.php'><-- 돌아가기</a>";
                exit();
        }


        $row = mysqli_fetch_array($ret);
	SESSION_START();
        $userid = $_SESSION['id'];
        $servicename = $row['vmname'];

?>
        <h2>서비스 삭제 확인</h2>
        <?php
                echo "$count 건의 삭제 정보가 검색 되었습니다<br><br>"
        ?>

        <form method="post" action="deletevm_result.php">
        아이디 : <input type = "text" name="userid" value=<?php echo $userid ?> READONLY><br>
        서비스 : <input type = "text" name="vmname" value=<?php echo $servicename ?> READONLY><br>

        <br><br>
        위 서비스을 삭제하겠습니까? &nbsp;&nbsp;&nbsp;
	<br><br>

	삭제하시려면 서비스명을 다시한번 입력해주세요.<br><br>

        확인 : <input type = "text" name="conf" ><br><br>

	<input type="submit" value="서비스 삭제">

        </form>

</body>
</html>

