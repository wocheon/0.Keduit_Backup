name=$1
vcpus=$2
ram=$3
iprows=$(ip ad sh ens32 |grep 10.1.1 | wc -l)
newipnum=$(expr $iprows + 80 )

cp /root/aa/sample/sample_centos-7.8\$.qcow2 /root/aa/${name}.qcow2
cp /root/ipchange.sh /root/ipchange1.sh
sed -i "s/changeip/$4/g" /root/ipchange1.sh

virt-customize -a /root/aa/${name}.qcow2 --upload /root/ipchange1.sh:/root/ --firstboot /root/ipchange1.sh --hostname worker$iprows

virt-install --name ${name} --vcpus ${vcpus} --ram ${ram} --noautoconsole  --network bridge=br01  --disk path=/root/aa/${name}.qcow2 --import 


echo "existed ip : $iprows"
echo "new ip :10.1.1.$newipnum"

echo "IPADDR${iprows}=10.1.1.$newipnum">>/etc/sysconfig/network-scripts/ifcfg-ens32
echo "done!"

grub2-mkconfig -o /boot/grub2/grub.cfg
systemctl restart network
ip ad sh ens32

systemctl restart firewalld

detect=$(docker node ls | grep worker$iprows | wc -l)

while [ $detect = 0 ]
do
sleep 2
echo ready
detect=$(docker node ls | grep worker$iprows | wc -l)
done
echo done


a=$(echo $((RANDOM%19+9000)))
check=$(mysql aloedb -h 10.1.1.4 -uuser1 -puser1 -e "select * from testnum where num = $a" | grep $a | wc -l)

until [ $check = 0 ]
do
echo "number : $a"
echo "in db row :$check"
echo "====================="
echo " "
a=$(echo $((RANDOM%19+9000)))
check=$(mysql aloedb -h 10.1.1.4 -uuser1 -puser1 -e "select * from testnum where num = $a" | grep $a | wc -l)
done
echo $a
echo $a
echo "in db row :$check"
mysql aloedb -h 10.1.1.4 -uuser1 -puser1 -e "insert into testnum values ($a)"
mysql aloedb -h 10.1.1.4 -uuser1 -puser1 -e "select * from testnum"

cp aa/sample/start.yml /root/db${iprows}.yml
sed -i "s/worker/worker${iprows}/g" /root/db${iprows}.yml
sed -i "s/9999/$a/g" /root/db${iprows}.yml
sed -i "s/num/$iprows/g" /root/db${iprows}.yml
docker stack deploy -c /root/db${iprows}.yml db-worker${iprows}


echo "iptables -t nat -A PREROUTING -p tcp -i ens32 -d 10.1.1.${newipnum} --dport 3306 -j DNAT --to ${4}:$a">>/root/aa/sample/portforward.sh

source /root/aa/sample/portforward.sh

