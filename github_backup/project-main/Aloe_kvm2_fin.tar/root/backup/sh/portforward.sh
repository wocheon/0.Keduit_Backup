iptables -t nat -A PREROUTING -p tcp -i ens32 -d 10.1.1.55 --dport 80 -j DNAT --to 192.168.1.55:10006
iptables -t nat -A PREROUTING -p tcp -i ens32 -d 10.1.1.55 --dport 4200 -j DNAT --to 192.168.1.55:4200
iptables -t nat -A PREROUTING -p tcp -i ens32 -d 10.1.1.56 --dport 80 -j DNAT --to 192.168.1.56:10010
iptables -t nat -A PREROUTING -p tcp -i ens32 -d 10.1.1.56 --dport 4200 -j DNAT --to 192.168.1.56:4200
