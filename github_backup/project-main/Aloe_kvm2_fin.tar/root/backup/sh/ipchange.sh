echo -e "TYPE=Ethernet\nNAME=eth0\nONBOOT=yes\nBOOTPROTO=none\nIPADDR=changeip\nPREFIX=24\nGATEWAY=192.168.1.12\nDNS1=8.8.8.8">/etc/sysconfig/network-scripts/ifcfg-eth0

systemctl restart network
#yum install -y httpd; systemctl enable httpd; systemctl restart httpd
systemctl stop firewalld; setenforce 0

#yum install -y yum-utils device-mapper-persistent-data lvm2
#yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
#yum install -y docker-ce
#systemctl start docker
systemctl enable docker

docker swarm join --token SWMTKN-1-28ok4lymgf5mut6e4a2i3nmgqucxakbxhyst40nds0x8fkquoy-6s5sdlw80iqt13b6420z1v03p 192.168.1.12:2377

docker run  --volume=/:/rootfs:ro  --volume=/var/run:/var/run:rw  --volume=/sys/fs/cgroup:/sys/fs/cgroup:ro  --volume=/dev/disk/:/dev/disk:ro  --privileged=true  --publish=8080:8080   --detach=true --name=cadvisor google/cadvisor:latest
