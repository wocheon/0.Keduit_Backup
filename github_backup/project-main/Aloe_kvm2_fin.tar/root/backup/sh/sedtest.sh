read -p "ip" ip1

a='a\'
sed -i "/\[web\]/${a}192.168.1.${ip1}" sedtest; cat sedtest
