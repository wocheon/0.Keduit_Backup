<!DOCTYPE html>

<head>
 <meta charset="utf-8"/>
 <title>Inwoo's WEBSRV</title>

</head>
<body>
<!-- 메뉴바-->
<?php include 'include/menu.php'?>
<!-- 본문-->
        <div style="font-size:4.5em; font-family:impact; color: #003458 " align="center">
        welcome to <br>my project webserver!
        <br>
        <br>
        </div>

<!-- 본문-이미지 -->
        <div style="font-size:2em; font-family:impact; color:#003458 "; align="center">
        <img src="img/home.png" width="600" height="500">
        <br>
        <br>
        <br>
        </div>

<!--연락처-->
<?php include 'include/bottom.html'?>

</body>
</html>
