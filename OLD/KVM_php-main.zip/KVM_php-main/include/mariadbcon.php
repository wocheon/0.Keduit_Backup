<?php 
$con = mysqli_connect("172.17.0.3", "root", "diak1351!","testdb") or die ("Mysql connection fail !!!");
echo "mariadb con success!";
?>
